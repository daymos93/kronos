__version__ = '0.0.2'
__libversion__ = '6.1'  # Latest lib version that the package is working with