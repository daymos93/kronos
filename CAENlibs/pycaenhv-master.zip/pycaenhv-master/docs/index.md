# Pure Python Module for CAEN High Voltage Modules

No compilation required. Just CAENHVWrapper Linux library.

